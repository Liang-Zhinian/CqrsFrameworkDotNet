﻿using System;
namespace MAR.Domain.EventHandlers
{
    public abstract class EventHandler
    {
        public EventHandler()
        {
        }
    }
}

﻿using System;
namespace MAR.Domain.Models.Security
{
    public class Branding
    {
    }
}

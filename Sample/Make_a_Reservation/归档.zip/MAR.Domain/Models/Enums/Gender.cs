﻿using System;
namespace MAR.Domain.Models.Enums
{
    public enum Gender
    {
        Male=0,
        Female
    }
}

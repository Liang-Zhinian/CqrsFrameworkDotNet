﻿using System;
namespace MAR.Domain.Models.Enums
{
    public enum ActionCode
    {
          None=0,
          Added,
          Updated,
          Failed,
          Removed
    }
}

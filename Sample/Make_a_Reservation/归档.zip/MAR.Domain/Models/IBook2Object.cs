﻿using System;
using MAR.Domain.Models.Security;

namespace MAR.Domain.Models
{
    public interface IBook2Object
    {
        Business Business { get; set; }
    }
}

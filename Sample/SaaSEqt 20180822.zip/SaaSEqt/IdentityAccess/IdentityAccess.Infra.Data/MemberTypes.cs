﻿namespace SaaSEqt.IdentityAccess.Infra.Data
{
    using System;

    public enum MemberTypes : byte
    {
        /// <summary>
        /// Indicates that the group member is a <see cref="Group"/>.
        /// </summary>
        Group = 0,

        /// <summary>
        /// Indicates that the group member is a <see cref="User"/>.
        /// </summary>
        User = 1
    }
}

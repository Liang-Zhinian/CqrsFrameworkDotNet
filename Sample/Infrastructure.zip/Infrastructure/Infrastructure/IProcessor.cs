﻿namespace Infrastructure
{
    public interface IProcessor
    {
        void Start();
        void Stop();
    }
}
